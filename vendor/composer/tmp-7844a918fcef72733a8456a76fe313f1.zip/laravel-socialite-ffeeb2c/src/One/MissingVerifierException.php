<?php

namespace Laravel\Socialite\One;

use InvalidArgumentException;

class MissingVerifierException extends InvalidArgumentException
{
    //
}
